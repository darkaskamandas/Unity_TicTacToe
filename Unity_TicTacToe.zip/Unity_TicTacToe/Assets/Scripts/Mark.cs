﻿
public enum Mark {
   None,
   X,
   O
}
